import type { Plugin } from "vite"
import express from "express"
import cors from "cors"
import apiRouter from "./routes/api"

export function adaptiveApiPlugin(): Plugin {
  const app = express()
  app.use(cors())
  app.use(express.json())
  app.use("/api", apiRouter)

  return {
    name: "adaptive-api-middleware",
    configureServer(server) {
      server.middlewares.use(app)
    },
  }
}
